import pygame
import threading 
import tkinter as tk

#Type text in the tk window and the pygame window will execute it.
#PygameWindow has variables self.screen, self.FPS, self.FIELD_WIDTH, self.FIELD_HEIGHT, for you to use.
#If you create a new variable (like self.var = 3) it will be stored between commands.

'''
Recommended test:
Type in to the tk window:

self.c = 255
#Then press go

self.screen.fill((self.c,0,self.c))
#Then press go. screen will fill pink.

pygame.mixer.music.load('test.ogg')
pygame.mixer.music.play()
#Then press go. Will play music, but some delay.

self.img = pygame.image.load('test.png')
self.screen.blit(self.img,self.img.get_rect(center=(self.FIELD_WIDTH/2,self.FIELD_HEIGHT/2)))
pygame.time.wait(4000)
#Then press go. Will wait 4 seconds, then put image in center.

self.img = pygame.transform.rotozoom(self.img,130,2)
self.screen.blit(self.img,self.img.get_rect(center=(self.FIELD_WIDTH/2,self.FIELD_HEIGHT/2)))
#Then press go. Will show big, rotated image.
'''

'''
KNOWN ERRORS:
    #The below will cause your program to freeze.
    pygame.display.set_caption("This causes an error")
'''

def sampleTKTextGetterFunc(text):
    #Displays input text along with the length.
    print(text + " " + str(len(text)))

class TKTextGetter:
    def __init__(self,func):
        #This class gets text from a TK window, in a separate thread, and passes it to func(text)
        self.func = func
        
        self.tkMaster = tk.Tk()
        self.mainFrame = tk.Frame(self.tkMaster)
        self.mainFrame.pack()

        self.goButton = tk.Button(self.mainFrame, text="go", command=self.__useText)
        self.goButton.pack(side=tk.LEFT)

        self.text = tk.Text(self.mainFrame)
        self.text.pack(side=tk.TOP)
        self.errorBox = tk.Text(self.mainFrame, background='blue', height=3, state=tk.DISABLED) #Originally blue, 3 lines of text high, read-only
        #The error box will only appear when there's an error.
        self.justHadError = 0 #When text is run with no error, my getNoError() function will be called.

        #If we just call self.tkMaster.mainloop(), it will run until user closes the window, and we can't do anything else until then.
        #So we gotta put it in its own thread.
        self.tkThread = threading.Thread(target=self.tkMaster.mainloop)

    def start(self):
        self.tkThread.start()

    def stop(self):
        self.tkMaster.quit()

    def __useText(self):
        #Called when press 'go'
        contents = self.text.get(1.0, tk.END)
        #First, correct for extra '\n' on the end.
        if contents.endswith('\n'):
            contents = contents[0:len(contents)-1]
        self.func(contents) #Send the text to the function

    def displayErrorMessage(self,message):
        self.errorBox.config(state=tk.NORMAL) #So can edit it
        self.errorBox.delete(1.0, tk.END)
        self.errorBox.insert(1.0,message)
        self.errorBox.config(state=tk.DISABLED)
        self.errorBox.config(background='red') #Shows up when there's an error
        self.errorBox.pack(side=tk.BOTTOM)
        self.justHadError = 1

    def getNoError(self):
        if self.justHadError:
            self.errorBox.destroy()

    def getAlive(self):
        return self.tkThread.is_alive()


class PygameWindow:
    def __init__(self):
        self.FPS = 60
        self.clock = pygame.time.Clock()
        self.FIELD_WIDTH = 400
        self.FIELD_HEIGHT = 600

        self.textGetter = TKTextGetter(self.getTKText)
        
    def getTKText(self,text):
        try:
            exec(text)
            self.textGetter.getNoError()
        except Exception as err:
            self.textGetter.displayErrorMessage(str(err))

    def start(self):
        pygame.mixer.init()
        self.screen = pygame.display.set_mode((self.FIELD_WIDTH,self.FIELD_HEIGHT))
        self.textGetter.start()

        self.__mainLoop()
    
    def __mainLoop(self):
        self.done = 0

        while not self.done:
            self.clock.tick(self.FPS)
            pygame.display.flip()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    self.textGetter.stop()
                    self.done = 1
                elif event.type == pygame.KEYDOWN:
                    pygame.display.set_caption("Your key was " + str(event.key))

            if not self.textGetter.getAlive():
                pygame.quit()
                self.done = 1
        

if __name__ == '__main__':
    PygameWindow().start() #This option allows you to do stuff to a pygame window in real-time. pygame.display.flip() is called automatically 60 times every second.
    #For above: remember, the screen is called self.screen, and if you initialize any variables to the class (self.etc), they will still be there the next time you press 'go'.
    #TKTextGetter(sampleTKTextGetterFunc).start() #If you use this option it will be a program that tells you how long your input text is.
